<?php
// Recibir directamente por GET (sin funciones ni foreachs)
$nombre  = $_GET['nombre'];
$edad    = $_GET['edad'];
$carrera = $_GET['carrera'];;
$c1      = $_GET['c1'];
$c2      = $_GET['c2'];
$c3      = $_GET['c3'];



// Calcular promedio (sin validaciones extra)
$promedio = ($c1 + $c2 + $c3) / 3;


if($promedio >= 6){
    $estatus = "aprobado";
}else{
    $estatus = "reprobado";
}

?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Resultado — Registro Académico</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 5 (simple) -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h1 class="h5 mb-0">Resultado del registro</h1>
      <a class="btn btn-sm btn-outline-secondary" href="registro-estudiantes.html">← Volver</a>
    </div>

    <div class="card">
      <div class="card-body">
        <p class="mb-2"><strong>Nombre:</strong> <?php echo $nombre; ?></p>
        <p class="mb-2"><strong>Edad:</strong> <?php echo $edad; ?> años
          <?php if ($edad >= 18){?>
            <span class="badge text-bg-dark ms-2">Estudiante adulto</span>
          <?php } else{ ?>
        </p>
          <span class="badge text-bg-dark ms-2">Estudiante joven</span>
        <?php } ?>
        <p class="mb-2"><strong>Carrera:</strong> <?php echo $carrera; ?></p>

        <hr>

        <p class="mb-1"><strong>Calificación 1:</strong> <?php echo $c1; ?></p>
        <p class="mb-1"><strong>Calificación 2:</strong> <?php echo $c2; ?></p>
        <p class="mb-3"><strong>Calificación 3:</strong> <?php echo $c3; ?></p>

        <div class="mb-0">
          <div><strong>Promedio:</strong> <?php echo number_format($promedio, 2); ?></div>
          <div><strong>Situación:</strong> <?php echo $estatus; ?></div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
