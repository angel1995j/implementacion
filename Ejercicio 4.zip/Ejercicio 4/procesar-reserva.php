<?php
// Datos por GET (simple)
$nombre = $_GET['nombre'];
$tipo   = $_GET['tipo'];
$noches = $_GET['noches'];

$desayuno        = isset($_GET['desayuno']);
$estacionamiento = isset($_GET['estacionamiento']);
$spa             = isset($_GET['spa']);

// Precios por noche según tipo
$precio_noche = 0;
if ($tipo === 'estandar') {
  $precio_noche = 800; 
}else if ($tipo === 'doble') { 
  $precio_noche = 1200; 
}
else if ($tipo === 'suite') { 
  $precio_noche = 2000;
}

// Subtotales
$subtotal_base = $precio_noche * $noches;

$extra_desayuno = 150 * $noches; 


$extra_est = 100 * $noches; 


$extra_spa = 500; 

$subtotal = $subtotal_base + $extra_desayuno + $extra_est + $extra_spa;

// Descuento 15% por más de 3 noches
if ($noches > 3) { 
  $descuento = $subtotal * 0.15; 
}

$total = $subtotal - $descuento;
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Resultado — Reserva de Hotel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h1 class="h5 mb-0">Desglose de reserva</h1>
      <a class="btn btn-sm btn-outline-secondary" href="reserva.html">← Volver</a>
    </div>

    <div class="card shadow-sm">
      <div class="card-body">
        <p class="mb-2"><strong>Nombre:</strong> <?php echo htmlspecialchars($nombre); ?></p>
        <p class="mb-2"><strong>Tipo de habitación:</strong> <?php echo htmlspecialchars($tipo); ?></p>
        <p class="mb-3"><strong>Noches:</strong> <?php echo $noches; ?></p>

        <hr>

        <p class="mb-1"><strong>Precio por noche:</strong> $<?php echo number_format($precio_noche, 2); ?></p>
        <p class="mb-1"><strong>Subtotal habitación:</strong> $<?php echo number_format($subtotal_base, 2); ?></p>

        <div class="mt-3 mb-2"><strong>Servicios extra</strong></div>
        <p class="mb-1">Desayuno: $<?php echo number_format($extra_desayuno, 2); ?></p>
        <p class="mb-1">Estacionamiento: $<?php echo number_format($extra_est, 2); ?></p>
        <p class="mb-3">Spa: $<?php echo number_format($extra_spa, 2); ?></p>

        <p class="mb-1"><strong>Subtotal:</strong> $<?php echo number_format($subtotal, 2); ?></p>
        <p class="mb-3"><strong>Descuento (si >3 noches):</strong> -$<?php echo number_format($descuento, 2); ?></p>

        <div class="alert alert-success mb-0">
          <strong>Total a pagar:</strong> $<?php echo number_format($total, 2); ?>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
