<h2>Nuevo cliente</h2>
<form method="get" action="insertar.php">
  <label>Nombre</label><br>
  <input type="text" name="nombre"><br><br>

  <label>Teléfono</label><br>
  <input type="text" name="telefono"><br><br>

  <button type="submit">Guardar</button>
  <a href="index.php">Cancelar</a>
</form>