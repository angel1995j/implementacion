CREATE DATABASE login_simple;
USE login_simple;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
);

-- Usuario de prueba (usuario: admin / contraseña: 1234)
INSERT INTO usuarios (usuario, password) VALUES ('admin', '1234');