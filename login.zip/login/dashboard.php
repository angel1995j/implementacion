<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Escritorio</title></head>
<body>
    <h2>Bienvenido, <?php echo $_SESSION['usuario']; ?> 🎉</h2>
    <p>Has iniciado sesión correctamente.</p>
    <a href="cerrar.php">Cerrar sesión</a>
</body>
</html>