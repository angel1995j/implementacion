<?php
$conexion = mysqli_connect("localhost", "root", "", "login_simple");

if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}
?>