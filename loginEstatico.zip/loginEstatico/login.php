<?php
session_start();
// Si ya está logueado, redirigir al home
if(isset($_SESSION['usuario'])) {
    header('Location: home.php');
    exit;
}

// Procesar el formulario de login
if($_POST) {
    $usuario = trim($_POST['usuario']);
    $password = trim($_POST['password']);
    
    // Credenciales fijas (para ejemplo)
    $usuario_valido = "admin";
    $password_valido = "1234";
    
    if($usuario === $usuario_valido && $password === $password_valido) {
        $_SESSION['usuario'] = $usuario;
        $_SESSION['login_time'] = date('Y-m-d H:i:s');
        header('Location: home.php');
        exit;
    } else {
        $error = "Usuario o contraseña incorrectos";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body { font-family: Arial; background: #f0f0f0; display: flex; justify-content: center; align-items: center; height: 100vh; }
        .login-box { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); width: 300px; }
        input[type="text"], input[type="password"] { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 10px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .error { color: red; text-align: center; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="login-box">
        <h2 style="text-align: center;">🔐 Iniciar Sesión</h2>
        
        <?php if(isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div>
                <label>Usuario:</label>
                <input type="text" name="usuario" value="<?php echo $_POST['usuario'] ?? ''; ?>" required>
            </div>
            <div>
                <label>Contraseña:</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit">Entrar</button>
        </form>
        
        <div style="text-align: center; margin-top: 15px; font-size: 12px; color: #666;">
            <strong>Credenciales de prueba:</strong><br>
            Usuario: admin<br>
            Contraseña: 1234
        </div>
    </div>
</body>
</html>