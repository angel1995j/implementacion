<?php
session_start();

// Verificar si hay sesión activa
if(!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

$usuario = $_SESSION['usuario'];
$login_time = $_SESSION['login_time'];

// Cerrar sesión
if(isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inicio</title>
    <style>
        body { font-family: Arial; background: #f0f0f0; margin: 0; }
        .header { background: #007bff; color: white; padding: 20px; display: flex; justify-content: space-between; align-items: center; }
        .container { max-width: 800px; margin: 20px auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .btn { padding: 10px 20px; background: #dc3545; color: white; text-decoration: none; border-radius: 5px; }
        .btn:hover { background: #c82333; }
        .welcome { text-align: center; margin-bottom: 30px; }
        .info-box { background: #e9ecef; padding: 15px; border-radius: 5px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🏠 Sistema de Inicio</h1>
        <div>
            <span>Hola, <strong><?php echo htmlspecialchars($usuario); ?></strong></span>
            <a href="?logout=true" class="btn" onclick="return confirm('¿Cerrar sesión?')">Cerrar Sesión</a>
        </div>
    </div>
    
    <div class="container">
        <div class="welcome">
            <h2>¡Bienvenido al Sistema! 🎉</h2>
            <p>Has iniciado sesión correctamente</p>
        </div>
        
        <div class="info-box">
            <h3>📊 Información de tu sesión:</h3>
            <p><strong>Usuario:</strong> <?php echo htmlspecialchars($usuario); ?></p>
            <p><strong>Hora de login:</strong> <?php echo $login_time; ?></p>
            <p><strong>ID de sesión:</strong> <?php echo session_id(); ?></p>
        </div>
        
        <div class="info-box">
            <h3>🚀 Características implementadas:</h3>
            <ul>
                <li>✅ Sistema de autenticación</li>
                <li>✅ Manejo de sesiones PHP</li>
                <li>✅ Protección de páginas privadas</li>
                <li>✅ Cierre de sesión seguro</li>
                <li>✅ Diseño responsive</li>
            </ul>
        </div>
        
        <div style="text-align: center; margin-top: 30px;">
            <p>Esta es tu página de inicio protegida. Solo usuarios autenticados pueden verla.</p>
        </div>
    </div>
</body>
</html>