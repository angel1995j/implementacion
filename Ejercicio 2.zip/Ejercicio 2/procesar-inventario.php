<?php
// Tomar valores vía GET (sin funciones, sin foreach, sin validaciones)
$p1_nombre   = $_GET['p1_nombre'];
$p1_precio   = $_GET['p1_precio'];
$p1_cantidad = $_GET['p1_cantidad'];
$p1_categoria= $_GET['p1_categoria'];

$p2_nombre   = $_GET['p2_nombre'];
$p2_precio   = $_GET['p2_precio'];
$p2_cantidad = $_GET['p2_cantidad'];
$p2_categoria= $_GET['p2_categoria'];

$p3_nombre   = $_GET['p3_nombre'];
$p3_precio   = $_GET['p3_precio'];
$p3_cantidad = $_GET['p3_cantidad'];
$p3_categoria= $_GET['p3_categoria'];


// Totales por producto (precio * cantidad)
$p1_total = $p1_precio * $p1_cantidad;
$p2_total = $p2_precio * $p2_cantidad;
$p3_total = $p3_precio * $p3_cantidad;

// Descuento 15% si categoría == "electrónicos"
if ($p1_categoria === 'electrónicos') { $p1_total = $p1_total * 0.85; }
if ($p2_categoria === 'electrónicos') { $p2_total = $p2_total * 0.85; }
if ($p3_categoria === 'electrónicos') { $p3_total = $p3_total * 0.85; }

// Total inventario
$total_inventario = $p1_total + $p2_total + $p3_total;
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Gestor de Inventario — Resultado</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h1 class="h5 mb-0">Inventario calculado</h1>
      <a class="btn btn-sm btn-outline-secondary" href="inventario.html">← Volver</a>
    </div>

    <div class="card shadow-sm">
      <div class="card-body">
        <!-- Producto 1 -->
        <h6 class="mb-2">Producto 1</h6>
        <p class="mb-1"><strong>Nombre:</strong> <?php echo htmlspecialchars($p1_nombre); ?></p>
        <p class="mb-1"><strong>Precio:</strong> <?php echo $p1_precio; ?></p>
        <p class="mb-1"><strong>Cantidad:</strong> <?php echo $p1_cantidad; ?></p>
        <p class="mb-1"><strong>Categoría:</strong> <?php echo htmlspecialchars($p1_categoria); ?>
          <?php if ($p1_categoria === 'electrónicos') { ?>
            <span class="badge text-bg-info ms-2">-15% aplicado</span>
          <?php } ?>
        </p>
        <p class="mb-3"><strong>Total:</strong> <?php echo number_format($p1_total, 2); ?></p>

        <hr>

        <!-- Producto 2 -->
        <h6 class="mb-2">Producto 2</h6>
        <p class="mb-1"><strong>Nombre:</strong> <?php echo htmlspecialchars($p2_nombre); ?></p>
        <p class="mb-1"><strong>Precio:</strong> <?php echo $p2_precio; ?></p>
        <p class="mb-1"><strong>Cantidad:</strong> <?php echo $p2_cantidad; ?></p>
        <p class="mb-1"><strong>Categoría:</strong> <?php echo htmlspecialchars($p2_categoria); ?>
          <?php if ($p2_categoria === 'electrónicos') { ?>
            <span class="badge text-bg-info ms-2">-15% aplicado</span>
          <?php } ?>
        </p>
        <p class="mb-3"><strong>Total:</strong> <?php echo number_format($p2_total, 2); ?></p>

        <hr>

        <!-- Producto 3 -->
        <h6 class="mb-2">Producto 3</h6>
        <p class="mb-1"><strong>Nombre:</strong> <?php echo htmlspecialchars($p3_nombre); ?></p>
        <p class="mb-1"><strong>Precio:</strong> <?php echo $p3_precio; ?></p>
        <p class="mb-1"><strong>Cantidad:</strong> <?php echo $p3_cantidad; ?></p>
        <p class="mb-1"><strong>Categoría:</strong> <?php echo htmlspecialchars($p3_categoria); ?>
          <?php if ($p3_categoria === 'electrónicos') { ?>
            <span class="badge text-bg-info ms-2">-15% aplicado</span>
          <?php } ?>
        </p>
        <p class="mb-3"><strong>Total:</strong> <?php echo number_format($p3_total, 2); ?></p>

        <div class="alert alert-primary mb-0">
          <strong>Valor total del inventario:</strong> <?php echo number_format($total_inventario, 2); ?>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
