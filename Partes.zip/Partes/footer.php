    </main>
    <footer>
        <p>© <?php echo date('Y'); ?> - Todos los derechos reservados.</p>
    </footer>
</body>
</html>