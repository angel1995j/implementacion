<!DOCTYPE html>
<html>
<head>
    <title>Mi Sitio Web</title>
</head>
<body>
    <header>
        <h1>Bienvenidos a mi sitio</h1>
        <nav>Inicio | Contacto | Ejercicios</nav>
    </header>
    <main>