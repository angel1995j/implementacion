<?php
include 'header.php';
?>

<h2>Contenido de la página</h2>
<p>Este es el contenido principal y único de esta página. El header y el footer se reutilizan.</p>
<p>Por ejemplo, podemos mostrar la fecha actual: <?php echo date('d/m/Y'); ?></p>

<?php
include 'footer.php';
?>