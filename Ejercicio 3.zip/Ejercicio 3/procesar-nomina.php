<?php
// Recibir datos por GET (simple)
$nombre       = $_GET['nombre'];
$horas        = $_GET['horas'];
$salario_hora = $_GET['salario_hora'];
$faltas       = $_GET['faltas'];

// Calcular salario base
$salario_base = $horas * $salario_hora;

// Descuento del 5% por cada día faltado
$descuento = $salario_base * (0.05 * $faltas);

// Bono del 10% si trabajó más de 40 horas
if ($horas > 40) {
  $bono = $salario_base * 0.10;
} else {
  $bono = 0;
}

// Salario final
$salario_final = $salario_base - $descuento + $bono;
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Resultado — Nómina</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h1 class="h5 mb-0">Desglose de Nómina</h1>
      <a class="btn btn-sm btn-outline-secondary" href="nomina.html">← Volver</a>
    </div>

    <div class="card shadow-sm">
      <div class="card-body">
        <p class="mb-2"><strong>Empleado:</strong> <?php echo htmlspecialchars($nombre); ?></p>
        <p class="mb-2"><strong>Horas trabajadas:</strong> <?php echo $horas; ?></p>
        <p class="mb-2"><strong>Salario por hora:</strong> $<?php echo number_format($salario_hora, 2); ?></p>
        <p class="mb-2"><strong>Días faltados:</strong> <?php echo $faltas; ?></p>

        <hr>

        <p><strong>Salario base:</strong> $<?php echo number_format($salario_base, 2); ?></p>
        <p><strong>Descuento por faltas:</strong> -$<?php echo number_format($descuento, 2); ?></p>
        <p><strong>Bono por horas extra:</strong> +$<?php echo number_format($bono, 2); ?></p>

        <div class="alert alert-success mt-3 mb-0">
          <strong>Salario final:</strong> $<?php echo number_format($salario_final, 2); ?>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
