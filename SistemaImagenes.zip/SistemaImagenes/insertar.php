<?php
// insertar.php
require 'conexion.php';

// Verificar que se haya enviado el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener nombre
    $nombre = $_POST['nombre'] ?? '';

    // Verificar que venga la imagen
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $imagen = $_FILES['imagen'];

        // Crear nombre único para la imagen
        $nombreImagen = time() . "_" . basename($imagen['name']);
        $rutaDestino = "uploads/" . $nombreImagen;

        // Mover imagen a carpeta uploads
        if (move_uploaded_file($imagen['tmp_name'], $rutaDestino)) {

            // Insertar en BD
            $sql = "INSERT INTO imagenes (nombre, imagen) VALUES ('$nombre', '$nombreImagen')";

            if ($conn->query($sql) === TRUE) {
                echo "<h3>Registro guardado correctamente</h3>";
                echo "<a href='formulario.php'>Subir otra imagen</a><br>";
                echo "<a href='mostrar.php'>Ver registros</a>";
            } else {
                echo "Error al insertar en la base de datos: " . $conn->error;
            }
        } else {
            echo "Error al mover la imagen al servidor.";
        }
    } else {
        echo "No se recibió ninguna imagen o hubo un error en la subida.";
    }
} else {
    echo "Acceso no válido.";
}

$conn->close();
?>
