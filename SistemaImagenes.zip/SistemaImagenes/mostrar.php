<?php
// mostrar.php
require 'conexion.php';

$sql = "SELECT * FROM imagenes ORDER BY id DESC";
$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mostrar Imágenes</title>
</head>
<body>

<h2>Registros Guardados</h2>

<a href="formulario.php">← Volver al formulario</a>
<hr>

<?php if ($resultado && $resultado->num_rows > 0): ?>
    <?php while($row = $resultado->fetch_assoc()): ?>
        <div style="margin-bottom:20px;">
            <strong><?php echo htmlspecialchars($row['nombre']); ?></strong><br>
            <img src="uploads/<?php echo htmlspecialchars($row['imagen']); ?>" width="200" alt="Imagen"><br>
            <hr>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p>No hay registros todavía.</p>
<?php endif; ?>

</body>
</html>
